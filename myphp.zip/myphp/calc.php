<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
    $x=10; $y=5;
    $txt="hello motherfucker";

    echo "sum is: " .  $x+$y . "</br>";
    echo "substraction is : " . $x - $y . "</br>";
   
    echo "division : " .$x / $y. "</br>";
   
    echo "multiplication : " . $x * $y . "</br>";
  
    ?>
</body>
</html>